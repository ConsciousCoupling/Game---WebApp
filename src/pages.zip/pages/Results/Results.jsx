// src/pages/Results/Results.jsx
export default function Results() {
  return (
    <div className="page results-page">
      <h2>Game Results</h2>
      <p>Feature coming soon.</p>
    </div>
  );
}