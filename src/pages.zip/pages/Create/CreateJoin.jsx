// src/pages/Create/CreateJoin.jsx
import { useNavigate } from "react-router-dom";
import "./CreateJoin.css";

export default function CreateJoin() {
  const navigate = useNavigate();

  return (
    <div className="create-join-page">
      <div className="create-join-card">
        <h1 className="cj-title">Welcome</h1>

        <p className="cj-subtitle">
          Start a new Intima-Date or join an existing one.
        </p>

        <div className="cj-buttons">

          {/* ⭐ Start New Game → goes to onboarding step 1 */}
          <button
            className="cj-btn primary"
            onClick={() => navigate("/onboarding")}
          >
            Start New Game
          </button>

          {/* ⭐ Join Existing Game → goes to new join screen */}
          <button
            className="cj-btn secondary"
            onClick={() => navigate("/join")}
          >
            Join Existing Game
          </button>

        </div>
      </div>
    </div>
  );
}