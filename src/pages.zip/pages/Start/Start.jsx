import { useNavigate } from "react-router-dom";
import "./Onboarding.css";

export default function Onboarding() {
  const navigate = useNavigate();

  return (
    <div className="onboarding-container simple-onboarding">
      
      <div className="onboarding-card simple-card">
        <h2 className="onboarding-title">Welcome</h2>

        <p className="onboarding-text">
          Choose how you'd like to begin.
        </p>

        <div className="onboarding-buttons">

          <button
            className="onboarding-btn primary-btn"
            onClick={() => navigate("/welcome")} // your existing first card screen
          >
            Start New Game
          </button>

          <button
            className="onboarding-btn secondary-btn"
            onClick={() => navigate("/join")} // placeholder for join screen
          >
            Join Existing Game
          </button>

        </div>
      </div>

    </div>
  );
}