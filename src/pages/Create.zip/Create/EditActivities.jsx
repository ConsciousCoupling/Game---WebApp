// src/pages/Create/EditActivities.jsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  loadDraftActivities,
  submitActivityProposal,
  saveDraftActivities,
  subscribeToDraftActivities,
  approveActivities
} from "../../services/activityStore";

import "./EditActivities.css";

export default function EditActivities() {
  const navigate = useNavigate();
  const { gameId } = useParams();

  const player = localStorage.getItem("player") || "playerOne";
  const other = player === "playerOne" ? "playerTwo" : "playerOne";

  const [activities, setActivities] = useState([]);
  const [approvals, setApprovals] = useState({
    playerOne: false,
    playerTwo: false
  });

  const [loading, setLoading] = useState(true);

  const defaultActivities = [
    {
      id: "a1",
      name: "Sensual Massage",
      cost: 5,
      description: "Give your partner a slow, gentle massage.",
      duration: "5–10 minutes"
    },
    {
      id: "a2",
      name: "Slow Dancing",
      cost: 3,
      description: "Hold each other and dance to a song.",
      duration: "1 song"
    },
    {
      id: "a3",
      name: "Compliment Round",
      cost: 2,
      description: "Exchange thoughtful compliments.",
      duration: "1–2 minutes"
    }
  ];

  // LOAD + SUBSCRIBE
  useEffect(() => {
    async function load() {
      const list = await loadDraftActivities(gameId);
      setActivities(list.length > 0 ? list : defaultActivities);
      setLoading(false);
    }

    load();

    const unsub = subscribeToDraftActivities(gameId, (data) => {
      if (data?.draft) setActivities(data.draft);
      if (data?.approvals) setApprovals(data.approvals);
    });

    return () => unsub();
  }, [gameId]);

  async function resetApprovals(updated) {
    setActivities(updated);
    await submitActivityProposal(gameId, updated);
  }

  function addActivity() {
    const updated = [
      ...activities,
      { id: crypto.randomUUID(), name: "", cost: 1, description: "", duration: "" }
    ];
    resetApprovals(updated);
  }

  function updateActivity(id, field, value) {
    const updated = activities.map(a =>
      a.id === id ? { ...a, [field]: value } : a
    );
    resetApprovals(updated);
  }

  function deleteActivity(id) {
    const updated = activities.filter(a => a.id !== id);
    resetApprovals(updated);
  }

  async function handleApprove() {
    await saveDraftActivities(gameId, activities);
    await approveActivities(gameId, player);
  }

  if (loading) return <div className="loading">Loading…</div>;

  const playerApproved = approvals[player];
  const bothApproved = approvals.playerOne && approvals.playerTwo;

  return (
    <div className="edit-activities-page">
      <div className="edit-card">
        <h2>Edit Activities</h2>
        <p className="edit-subtext">Customize together. Changes reset approval.</p>

        <div className="activity-list">
          {activities.map(a => (
            <div className="activity-item" key={a.id}>
              <input
                className="activity-input"
                value={a.name}
                placeholder="Name"
                onChange={e => updateActivity(a.id, "name", e.target.value)}
              />

              <input
                className="activity-input number"
                type="number"
                value={a.cost}
                onChange={e => updateActivity(a.id, "cost", Number(e.target.value))}
              />

              <textarea
                className="activity-textarea"
                value={a.description}
                placeholder="Description"
                onChange={e => updateActivity(a.id, "description", e.target.value)}
              />

              <input
                className="activity-input"
                value={a.duration}
                placeholder="Duration"
                onChange={e => updateActivity(a.id, "duration", e.target.value)}
              />

              <button className="delete-btn" onClick={() => deleteActivity(a.id)}>✕</button>
            </div>
          ))}
        </div>

        <button className="add-btn" onClick={addActivity}>+ Add Activity</button>

        {!playerApproved ? (
          <button className="ready-btn" onClick={handleApprove}>
            Send to {other === "playerOne" ? "Player 1" : "Player 2"}
          </button>
        ) : (
          <div className="waiting-message">
            Waiting for {other === "playerOne" ? "Player 1" : "Player 2"}…
          </div>
        )}

        {bothApproved && (
          <button
            className="continue-btn"
            onClick={() => navigate(`/create/activities-review/${gameId}`)}
          >
            Continue →
          </button>
        )}
      </div>
    </div>
  );
}