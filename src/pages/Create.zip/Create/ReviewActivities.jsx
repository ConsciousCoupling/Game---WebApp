// src/pages/Create/ReviewActivities.jsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  subscribeToDraftActivities,
  approveActivities,
  finalizeActivities
} from "../../services/activityStore";

import "./ReviewActivities.css";

export default function ReviewActivities() {
  const { gameId } = useParams();
  const navigate = useNavigate();

  const player = localStorage.getItem("player") || "playerOne";

  const [activities, setActivities] = useState([]);
  const [approvals, setApprovals] = useState({
    playerOne: false,
    playerTwo: false
  });

  useEffect(() => {
    const unsub = subscribeToDraftActivities(gameId, (data) => {
      if (data?.draft) setActivities(data.draft);
      if (data?.approvals) setApprovals(data.approvals);
    });

    return () => unsub();
  }, [gameId]);

  async function approve() {
    await approveActivities(gameId, player);
  }

  async function finalize() {
    await finalizeActivities(gameId);
    navigate(`/create/summary/${gameId}`);
  }

  const bothApproved = approvals.playerOne && approvals.playerTwo;

  return (
    <div className="review-wrapper">
      <h1 className="review-title">Review Activities</h1>
      <p className="review-subtitle">Both players must approve.</p>

      <div className="review-list">
        {activities.map(a => (
          <div className="review-row" key={a.id}>
            <div className="rev-name">{a.name}</div>
            <div className="rev-duration">{a.duration}</div>
            <div className="rev-cost">{a.cost} tokens</div>
          </div>
        ))}
      </div>

      <div className="approval-box">
        <div className="approval-status">
          <span className={approvals.playerOne ? "approved" : "pending"}>
            Player 1: {approvals.playerOne ? "✓ Approved" : "Waiting…"}
          </span>
          <span className={approvals.playerTwo ? "approved" : "pending"}>
            Player 2: {approvals.playerTwo ? "✓ Approved" : "Waiting…"}
          </span>
        </div>

        {!approvals[player] && (
          <button className="approve-btn" onClick={approve}>
            Approve Activity List
          </button>
        )}
      </div>

      <div className="review-actions">
        <button
          className="back-btn"
          onClick={() => navigate(`/create/activities/${gameId}`)}
        >
          ← Back to Editing
        </button>

        {bothApproved && (
          <button className="continue-btn" onClick={finalize}>
            Finalize & Continue →
          </button>
        )}
      </div>
    </div>
  );
}