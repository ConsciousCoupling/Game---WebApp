// src/pages/Create/PlayerOne.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { saveSetup } from "../../services/setupStorage";
import generateGameId from "../../services/gameId";
import { db } from "../../services/firebase";
import { doc, setDoc } from "firebase/firestore";
import "./Create.css";

export default function PlayerOne() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [color, setColor] = useState("#ff3e84");

  const colors = [
    "#ff3e84",
    "#3e8bff",
    "#ffd34f",
    "#37d67a",
    "#ff00cc",
    "#9b59ff",
    "#ff7a2f"
  ];

  async function handleContinue() {
    if (!name.trim()) return;

    const gameId = generateGameId();

    // Create initial Firestore entry
    await setDoc(doc(db, "games", gameId), {
      activityDraft: [],
      approvals: { playerOne: false, playerTwo: false },
      finalActivities: []
    });

    saveSetup({
      gameId,
      playerOneName: name,
      playerOneColor: color
    });

    navigate("/create/player-two");
  }

  return (
    <div className="create-container">
      <div className="create-card">

        <button
          className="secondary-btn"
          onClick={() => navigate("/onboarding/slides")}
        >
          ← Back
        </button>

        <h1 className="create-title">Player One</h1>

        <input
          className="create-input"
          placeholder="Your name…"
          value={name}
          onChange={e => setName(e.target.value)}
        />

        <label className="color-picker-label">Choose your color:</label>

        <div className="color-picker-row">
          {colors.map(c => (
            <button
              key={c}
              className={`color-swatch ${color === c ? "selected" : ""}`}
              style={{ background: c }}
              onClick={() => setColor(c)}
            />
          ))}
        </div>

        <button
          className={`create-btn primary-btn ${!name.trim() ? "disabled" : ""}`}
          onClick={handleContinue}
        >
          Continue →
        </button>

      </div>
    </div>
  );
}