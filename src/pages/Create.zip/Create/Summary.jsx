// src/pages/Create/Summary.jsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { saveGameToCloud } from "../../services/gameStore";
import { loadSetup } from "../../services/setupStorage";
import { loadFinalActivities } from "../../services/activityStore";
import { initialGameState } from "../../game/initialGameState";

import "./Summary.css";

export default function Summary() {
  const navigate = useNavigate();
  const { gameId } = useParams();

  const [playerOneName, setP1Name] = useState("");
  const [playerTwoName, setP2Name] = useState("");
  const [playerOneColor, setP1Color] = useState("#ffffff");
  const [playerTwoColor, setP2Color] = useState("#ffffff");

  const [activities, setActivities] = useState([]);

  useEffect(() => {
    async function loadData() {
      const setup = loadSetup();

      if (setup) {
        setP1Name(setup.playerOneName || "");
        setP2Name(setup.playerTwoName || "");
        setP1Color(setup.playerOneColor || "#ffffff");
        setP2Color(setup.playerTwoColor || "#ffffff");
      }

      const final = await loadFinalActivities(gameId);
      setActivities(final || []);
    }

    loadData();
  }, [gameId]);

  async function startGame() {
    const setup = loadSetup();

    const state = JSON.parse(JSON.stringify(initialGameState));

    state.gameId = gameId;
    state.players[0].name = playerOneName;
    state.players[0].color = playerOneColor;
    state.players[1].name = playerTwoName;
    state.players[1].color = playerTwoColor;

    state.negotiatedActivities = activities;

    await saveGameToCloud(gameId, state);

    localStorage.setItem(`game-${gameId}`, JSON.stringify(state));

    navigate(`/game/${gameId}`);
  }

  return (
    <div className="summary-page">
      <div className="summary-card">
        <h2 className="summary-title">Ready to Begin?</h2>

        <div className="summary-players">
          <p style={{ color: playerOneColor }}><strong>Player 1:</strong> {playerOneName}</p>
          <p style={{ color: playerTwoColor }}><strong>Player 2:</strong> {playerTwoName}</p>
        </div>

        <div className="summary-activities">
          <h3>Agreed Activity List</h3>

          {activities.length === 0 ? (
            <p>No activities — please go back.</p>
          ) : (
            <ul>
              {activities.map(a => (
                <li key={a.id}>
                  <strong>{a.name}</strong> — {a.duration}
                  <span className="cost">({a.cost} tokens)</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <button className="summary-start-btn" onClick={startGame}>
          Start Game
        </button>
      </div>
    </div>
  );
}