// src/pages/Create/PlayerTwo.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loadSetup, saveSetup } from "../../services/setupStorage";
import "./Create.css";

export default function PlayerTwo() {
  const navigate = useNavigate();
  const setup = loadSetup();

  const [name, setName] = useState("");
  const [color, setColor] = useState("#3e8bff");

  const colors = [
    "#ff3e84",
    "#3e8bff",
    "#ffd34f",
    "#37d67a",
    "#ff00cc",
    "#9b59ff",
    "#ff7a2f"
  ];

  function handleContinue() {
    if (!name.trim()) return;

    saveSetup({
      ...setup,
      playerTwoName: name,
      playerTwoColor: color
    });

    const gameId = setup?.gameId;
    if (!gameId) {
      alert("No gameId found. Restart setup.");
      return;
    }

    navigate(`/create/activities/${gameId}`);
  }

  return (
    <div className="create-container">
      <div className="create-card">

        <button
          className="secondary-btn"
          onClick={() => navigate("/create/player-one")}
        >
          ← Back
        </button>

        <h1 className="create-title">Player Two</h1>

        <input
          className="create-input"
          placeholder="Your name…"
          value={name}
          onChange={e => setName(e.target.value)}
        />

        <label className="color-picker-label">Choose your color:</label>

        <div className="color-picker-row">
          {colors.map(c => (
            <button
              key={c}
              className={`color-swatch ${color === c ? "selected" : ""}`}
              style={{ background: c }}
              onClick={() => setColor(c)}
            />
          ))}
        </div>

        <button
          className={`create-btn primary-btn ${!name.trim() ? "disabled" : ""}`}
          onClick={handleContinue}
        >
          Continue →
        </button>

      </div>
    </div>
  );
}