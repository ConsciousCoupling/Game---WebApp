// src/App.jsx
import AppRoutes from "./routes/AppRoutes";

export default function App() {
  return (
    <div className="app-container">
      <AppRoutes />
    </div>
  );
}