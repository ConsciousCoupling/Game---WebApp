export default function Home() {
  return <h1>IntimaDate — Clean Build Ready</h1>;
}