// src/game/promptDecks.js

export const promptDecks = {
  1: [],
  2: [],
  3: [],
  4: [],
};