// src/game/data/activityList.js

export const ACTIVITIES = [
  { id: 101, name: "Hand Massage", cost: 10, description: "Massage your partner’s hands." },
  { id: 102, name: "Foot Massage", cost: 20, description: "Massage your partner’s feet." },
  { id: 103, name: "Face Massage", cost: 25, description: "A gentle face massage." },
  { id: 104, name: "Scalp Massage", cost: 25, description: "Relaxing scalp stimulation." },
  { id: 105, name: "Eye Gazing", cost: 10, description: "Look into each other's eyes for 60 seconds." },
  { id: 106, name: "Drawing on Back", cost: 15, description: "Trace shapes gently on their back." },
  { id: 107, name: "Butterfly/Eskimo Kisses", cost: 10, description: "Cute close-contact kisses." },
  { id: 108, name: "Feed Candy/Fruit", cost: 20, description: "Feed your partner something sweet." },
  { id: 109, name: "Blindfold for 2 minutes", cost: 40, description: "Use a blindfold to heighten senses." },
  { id: 110, name: "Handcuff for 2 minutes", cost: 50, description: "Try light restraint play." },
  { id: 111, name: "Strip RPS", cost: 75, description: "Strip rock/paper/scissors." },
  { id: 112, name: "Spanking", cost: 100, description: "Deliver consensual playful spanks." },
  { id: 113, name: "Spicy Selfie", cost: 125, description: "Take a spicy selfie for your partner." },
  { id: 114, name: "Demonstrate Sex Position", cost: 150, description: "Demonstrate your favorite position." },
  { id: 115, name: "Naked Gymnastics Move", cost: 250, description: "Perform a naked gymnastics move." },
];