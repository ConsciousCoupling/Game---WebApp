export const ACTIVITIES = [
  {
    id: "slow_kiss",
    name: "Slow Kiss",
    cost: 5,
    description: "Kiss your partner slowly for 30 seconds."
  },
  {
    id: "neck_caress",
    name: "Neck Caress",
    cost: 8,
    description: "Trace their neck with your fingers."
  },
  {
    id: "compliment_flood",
    name: "Compliment Flood",
    cost: 3,
    description: "Give your partner 5 sincere compliments."
  },
  {
    id: "lap_sit",
    name: "Lap Sit",
    cost: 10,
    description: "Sit on your partner's lap or invite them onto yours."
  },
  {
    id: "breathing_sync",
    name: "Breathing Sync",
    cost: 4,
    description: "Match your breathing together for one minute."
  }
];